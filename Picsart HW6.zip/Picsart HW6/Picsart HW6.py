# f = open('dic.txt')
# dic = {}

# for line in f:
#     pair = line.split(', ')
#     dic[pair[0]] = pair[1][:-1]

# print(dic)

# import dis

# def myfunc(alist):
#     return len(alist)

# dis.dis(myfunc)

# #So we have five parameters in the first line of the ourput 
# #First is the line(13) second is the instruction offset in bytes, 
# # third is the operation(LOAD_GLOBAL) which is on offset 0 bytes from start
# # and that operation takes (len) as argument and Loads the global named co_names[len>>1] onto the stack. 
# # LOAD_FAST is on offset 2, Pushes a reference to the local co_varnames[alist] onto the stack.
# # CALL_FUNCTION is on offset 4, pops all arguments and the callable object off the stack, calls the callable object with those arguments, 
# # and pushes the return value returned by the callable object.
# # and RETURN_VALUE is on offset 6, returns with TOS to the caller of the function.


    