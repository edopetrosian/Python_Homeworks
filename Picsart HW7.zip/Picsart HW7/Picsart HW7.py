# import PyPDF2

# f = open("contacts.txt", "a")
# f.write("First_Name Last_Name, Title, Extension, Email")

# # Open the PDF file
# with open('Business_Proposal.pdf', 'rb') as file:
#     reader = PyPDF2.PdfReader(file)
#     page = reader.pages[1].extract_text()
#     for line in page:
#         f.write(line)

# f.close()

# import PyPDF2

# dic = {}
# lst = []

# with open('US_Declaration.pdf','rb') as file:
#     reader = PyPDF2.PdfReader(file)
#     page1 = reader.pages[3].extract_text()
#     page2 = reader.pages[4].extract_text()
#     page1 = page1.splitlines()
#     page2 = page2.splitlines()

#     for line in page1:
#         line = line.split('   ')
#         for i in line:
#             if i[1:7] == 'Column':
#                 i = i[len('[Column ?] '):]
#             if i != '' and len(i) < 40:
#                 lst.append(i)
            
        
#     for line in page2:
#         line = line.split('   ')
#         for i in line:
#             if i[1:7] == 'Column':
#                 i = i[len('[Column ?] '):]
#             if i != '' and i != ' ':
#                 lst.append(i)

#     for i in range(len(lst) ):
#         if lst[i][-1] == ':':
#             key = lst[i]
#             dic[key] = []
#             j = i + 1
#             while lst[j][-1] != ':':
#                 dic[key].append(lst[j])
#                 if j != len(lst) -1:
#                     j += 1
#                 else:
#                     break

# print(dic)
    
            


    





    
    


